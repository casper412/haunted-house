/* Database Interface for Pictures Database by Matthew Hall
 *
 */

package Database        ;

import javax.sql.*      ;
import java.sql.*       ;
import javax.naming.*   ;
import javax.servlet.*;
import javax.servlet.http.*;
import java.text.SimpleDateFormat ;
import java.util.* ; 

public class SessionDB
{
    private DataSource  ds              ;
    private Connection  con             ;
    private Context     cxt             ;
    private int         m_init		;
    private Statement   picStmt		;
    private Statement   sessStmt        ;
    private ResultSet   picRes          ;
    private ResultSet   sessRes         ;
    
    private String[]    woodList = {"** Dark **","Walnut","Mahogany","Padauk","** Medium **",
                                    "Cherry","Mahogany","Oak","Birch burl","Elm","Poplar",
                                    "** Light **","Cherry","Alder","Maple","Wormy maple",
                                    "Ash","Maple burl"} ;        ;
    
    private float[]     rates    = { 3,5,
                                    (float)6.5,10,
                                    15,17,
                                    20} ;                                
    
    private HttpServletRequest request  ;
    
    private String temp     ;
    private String dispURL     = "http://www.paintingwithasaw.com:8080/PaintSaw/dispPic.jsp"  ;
    private String jspURL      = "http://www.paintingwithasaw.com:8080/PaintSaw/dispCart.jsp" ;
    //Defines Info
    private String bgcolor     = "FBF8E8" ; 

    //On Init - Open SawPictures Database
    public void Init(HttpServletRequest res)
    {
	m_init = 0 ;
        request = res ;

	try 
	{
            cxt = new InitialContext(); 
            Context envCtx = (Context) cxt.lookup("java:comp/env");
            ds = (DataSource) envCtx.lookup("jdbc/PaintSawDB");

            con  = ds.getConnection()   ; 
            picStmt = con.createStatement();
            sessStmt = con.createStatement();

            envCtx.close() ;
            
        }
        catch(NamingException e) 
	{
		m_init = 2 ;
                temp = e.getMessage() ; 
	}
        catch(SQLException ex) 
	{
		m_init = 1 ;
                temp = ex.getMessage() ; 
        }
        
    }//end init
    
    //On Close - Close Connection
    public void Close()
    {
	try
	{
                if(con != null)
                {
                    con.close() ;
                    con = null  ;
                }
                            
        	if(picStmt != null)
                {
                    picStmt.close();
                    picStmt = null ;
                }
                if(sessStmt != null)
                {
                    sessStmt.close();
                    sessStmt = null ;
                }
                if(sessRes != null)
                {
                    sessRes.close();
                    sessRes = null ;
                }
                if(picRes != null)
                {
                    picRes.close();
                    picRes = null ;
                }
	}
        catch(SQLException ex) 
	{
		//Do nothing we are exiting
	}

        if(cxt != null)
        {
            try
            {
                cxt.close() ;
                cxt = null  ;
            }
            catch(javax.naming.NamingException ex)
            {
                //Do Nothing we are exiting
            }
         }
        
    }//end destroy
    
    //Query Database
    public String doQuery()
    {     
        //Check that Init was called
        if(m_init > 0)
        {
            return temp ;
        }
        
        //Init
        HttpSession session = request.getSession(true);

        //Join the SessionTable with the Pics table for the URLs and Prices
        String query = "SELECT SessionTable.*, pics.turl, pics.price, pics.name, pics.clock FROM SessionTable, pics WHERE SessionTable.item = pics.dex AND SessionTable.sessionID='" + 
                        session.getId() + "' ORDER BY SessionTable.item" ;
        try 
	{
            //Load Items Bought
            sessRes = sessStmt.executeQuery(query);
          
	} 
       	catch(SQLException ex) 
	{
           m_init = 4 ;
           return "SQL Exception: " + ex.getMessage() ;
        }

        return "" ; 
        
    } //end do Query
    
    ////////////////////////////////////////////////////////////////////
    //Used in Loop to Write out All Items
    public String getNextItem()
    {
        String ret = "" ;
        
        if(sessRes == null)
            return "" ; 
        
        try
        {
            if(sessRes.next())
            {
                ret += "<TR>" ; //start row
                
                ret += "<TD ALIGN=center>" ; //Start Cell with pic and number
                ret += "<A HREF=\"" + dispURL + "?pic=" + sessRes.getString("item") + "\">" ; //Start Link
                ret += sessRes.getString("name") + "<BR>\n" ;
                ret += "<img border=0 src=\"" + sessRes.getString("turl") + "\">" ;
                ret += "</a>"  ; //end link
                ret += "</TD>\n" ; //end cell with thumbnail
                
                ret += "<TD ALIGN=center>" ; //Start Cell with Qty
                ret += "<input type=\"text\" name=" + sessRes.getString("dex") + 
                       "-quantity size=2 maxlength=2 value=" + sessRes.getString("quantity") + ">" ;
                ret += "</TD>\n"             ; //End Cell
                
                ret += "<TD ALIGN=center>" ; //Start Cell with Wood
                ret += getWoodInput(sessRes.getString("dex"),sessRes.getString("wood")) ;
                ret += "</TD>\n"             ; //End Cell
                
                ret += "<TD ALIGN=center>" ; //Start Cell with clock
                ret += getClockInput(sessRes.getString("pics.clock"), 
                                     sessRes.getString("dex"), 
                                     sessRes.getString("SessionTable.clock")) ;
                
                ret += "</TD>\n"             ; //End Cell
                
                //Delete Button
                ret += "<TD ALIGN=center>" ; //Start Cell with Delete
                ret += sessRes.getString("price") ;
                ret += "</TD>\n"           ; //End Cell
                
                ret += "<TD ALIGN=center>" ; //Start Cell with Delete
                ret += "<A HREF=\"" + jspURL + "?delete=" + sessRes.getString("dex") + "\">"  ;
                ret += "<img border= 0 src=\"http://www.paintingwithasaw.com/images/delete.gif\">" ; 
                ret += "</A>"           ;
                ret += "</TD>\n"           ; //End Cell
                
                ret += "</TR>" ; //end row 
            }

        }
        catch(SQLException ex) 
	{
            return "SQLException: " + ex.getMessage() ;
        }
        
        return ret ; 
        
    }//end doGet

    //////////////////////////////////////////////////////////
    //Process update requests
    public String UpdateItems()
    {
        HttpSession session = request.getSession(true);
        
        Enumeration items = request.getParameterNames() ;
        ArrayList al = new ArrayList() ; 
        
        String    ret  = ""    ; 
        boolean   skip = false ;
        
        //Dump all Parameters into a List to Sort
        while(items.hasMoreElements())
            al.add(items.nextElement()) ;
        
        Collections.sort(al) ;
        
        //Remove the Submit
        al.remove("submit.x") ;
        al.remove("submit.y") ;
        al.remove("submit")   ;
        al.remove("proceed")  ;
        al.remove("proceed.x") ;
        al.remove("proceed.y") ;
        
        if(al.contains("add") || al.contains("delete") || al.size() == 0)
            return "" ;
        
        if(al.size() % 3 != 0)
            return "Improper Imput" ;
        
        //Loop over parameters
        while(!al.isEmpty())
        {
            String query = "UPDATE SessionTable SET " ; 
            
            String index  = (String)al.get(0);
            String temp[] = index.split("-") ; 
            
            if(temp.length != 2)
                return "Invalid Input" ;
            
            index = temp[0].trim().toLowerCase() ; 
            
            //Loop Grabbing the first three properties
            for(int si = 0 ; si < 3 ; si++)
            {
                String item = (String) al.remove(0)     ; 
                temp        = item.split("-")           ;
                
                if(temp.length != 2)
                    return "Invalid Input" ; 

                if(index.compareTo(temp[0].trim().toLowerCase()) != 0)
                    return "-" + index + "--" + temp[0] + "-" ; //"Invalid Parameter Count" ;
                
                //If they say they want zero of something
                //then delete the item
                if(temp[1].compareToIgnoreCase("quantity") == 0)
                {
                    String test = request.getParameterValues(item)[0] ;
                    test = test.trim() ;
                    
                    //Try to Parse the int
                    try
                    {
                        if(Integer.parseInt(test) == 0)
                        {
                            skip = true    ;
                            DelItem(index) ;
                            //No Break, Loop Will Finish and Delete 
                            //all the appropriate from input
                        }
                    }
                    catch(java.lang.NumberFormatException ex)
                    {
                        skip = true ;
                        DelItem(index) ; 
                        //Remove Items with crap quantities
                    }
                    
                }//end check quantity zero
                
                query += temp[1] + " = '" + request.getParameterValues(item)[0] + "'";
                
                if(si != 2)
                    query += ", " ;
                
            }//end loop removing three things
            
            //Finish Query String
            query += " WHERE sessionID='" + session.getId() + "' AND dex= " + index ; 
            
            //Try Updating the Item
            try
            {
                if(!skip)
                    sessStmt.executeUpdate(query) ;
            }
            catch(SQLException ex)
            {
               return ex.getMessage() ; 
            }
            
            skip = false ;
        }//end loop over inputs    
        
        return "" ;
    }//end UpdateItems
    
    //////////////////////////////////////////////////////////
    //Drop an item from the database
    public String DelItem(String udex)
    {
        if(m_init > 0 || udex == null)
            return "" ; //nothing to do
        
        HttpSession session = request.getSession(true);
        
        //Else there is a parameter called delete so we must remove that item
        //Added Session ID in there to prevent other user from messing up
        //Other Sessions
        String query = "DELETE FROM SessionTable WHERE sessionID = '" + session.getId() + 
                       "' AND dex = " + udex ;
        try
        {
            sessStmt.executeUpdate(query) ; 
            return "" ; 
        }
        catch(SQLException ex) 
	{
           return "SQL Exception: " + ex.getMessage() ;
        }
    }//end Drop Item
    //////////////////////////////////////////////////////////
    //Insert a picture to the data base 
    public String AddItem(String index)
    {
        if(m_init > 0 || index == null)
        {
            return "" ;
        }
        
        String query = "SELECT * FROM pics WHERE dex = " + index ;
        
        try 
	{
            picRes = picStmt.executeQuery(query);
            if(!picRes.next())
            {
                return "Invalid Picture" ;
            }

            //Insert the New Picture
            //Use the Session to Key into Database
            HttpSession session = request.getSession(true);

            java.sql.Date created = new java.sql.Date(session.getCreationTime());

            String dateFormat = "yyyy-MM-dd hh-mm-ss";
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
  
            //DB order sessId,sessCreated,item,size,wood,clock
            query =  "INSERT INTO SessionTable " ;
            query += "(sessionID, sessCreated, item, quantity, size, wood, clock) VALUES ('" ;
            query += session.getId()     + "','";
            query += sdf.format(created) + "','";
            query += index               + "','";
            query += "1', 'Standard','" + picRes.getString("wood") + "','0')" ; 
            
            //Add the Picture
            sessStmt.executeUpdate (query) ;
            
            //Close the Pic Table Query
            picRes.close() ; 
            picRes = null  ;
                
	} 
       	catch(SQLException ex) 
	{
           return "SQL Exception: " + ex.getMessage() ;
        }
        
        return "" ;
        
    }//add pic
    
    ///////////////////////////////////////////////////////////////////
    //Return a String For the Clock Input
    private String getClockInput(String clockType, String dex, String clock)
    {
        if(clockType.compareToIgnoreCase("n/a") == 0)   
        {
            return "<input type=\"hidden\" name=" + dex + 
                       "-clock value=\"-1\">No Clock" ; 
        }
        //else
        
        try
        {
            ResultSet res = picStmt.executeQuery("SELECT * FROM clocks WHERE size = '" +
                                                 clockType + "'") ;
        
            //For Empty Lookups
            if(!res.first())
            {
                return "<input type=\"hidden\" name=" + dex + 
                           "-clock value=\"-2\">" +
                           "Clock as Pictured";  
            }
        
            //else
            //Create Option Drop Down for all choices
            String ret = "<SELECT name=" + dex + "-clock>\n" ;
            do
            {
                ret += "<OPTION VALUE=" + res.getString("dex") ;
                
                if(res.getString("dex").compareToIgnoreCase(clock) == 0)
                    ret += " Selected=true" ;
                
                ret += ">" + res.getString("size") 
                        + " " + res.getString("face") +
                        "  w/ " + res.getString("numerals") + " Numerals</OPTION>\n" ;
            
            }while(res.next()) ;
            
            res.close() ;
            
            return ret ;
        }
        catch(SQLException ex)
        {
           return "<input type=\"hidden\" name=" + dex + 
                  "-clock value=\"-2\">" +
                  "Database Error";  
        }

    } //end clock input
    
    ///////////////////////////////////////////////////////////////////
    //Get Wood Type Input Box
    private String getWoodInput(String dex, String wood)
    {
        String ret = "<select name=\"" + dex + "-wood\">\n" ; 
        
        //Split out multiple wood types
        String temp[] = wood.split(",") ;
        if(temp.length > 1)
            wood = temp[0] ;
        
        wood.trim() ;
        
        //Add all woods
        for(int si = 0 ; si < woodList.length ; si++)
        {
            ret += "<option" ;
            if(wood.compareToIgnoreCase(woodList[si]) == 0)
            {
                ret += " Selected=true" ;
            }
            
            ret += ">" + woodList[si] + "</option>" ;
            
        }//end loop
        
        return ret ;
    }//end Get Wood Input
    
    //////////////////////////////////////////////////////////////////
    //Get Subtotal
    public float getSubTotal()
    {
        float subtotal = 0 ; 
        
        try
        {
            if(!sessRes.first())
                return 0 ; 
            
            //Loop over Items Summing Prices
            do
            {
                //Get Price and Clean it up
                String price = sessRes.getString("price") ; 
                price = price.trim() ; 
                price = price.replace('$', '0') ;
                
                if(price.indexOf(',') >= 0)
                {
                    price = (price.split(","))[0] ; 
                }
                
                //Parse Out Price and Multiple by Count
                float temp = Float.parseFloat(price) ; 
                temp *= sessRes.getInt("quantity") ; 
                
                subtotal += temp ; 
                
            }while(sessRes.next()) ; //end loop
            
            return subtotal ;
        }
        catch(SQLException ex)
        {
            return -1 ;
        }
        
    }//end get SubTotal
    
    ////////////////////////////////////////////////////////////
    public float getRate(float x)
    {
        if( x <= 0)
            return 0 ;
        else if(x <= 15)
            return rates[0] ;
        else if(x <= 30)
            return rates[1] ; 
        else if(x <= 50)
            return rates[2] ; 
        else if(x <= 75)
            return rates[3] ; 
        else if(x <= 100)
            return rates[4] ; 
        else if(x <= 125)
            return rates[5] ; 
        else
            return rates[6] ; 

    }//end getRate
    
}//end class def
