/* Dynamic Menu by Matthew Hall
 *
 */

import javax.sql.*      ;
import java.sql.*       ;
import javax.naming.*   ;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.text.NumberFormat ;

public class ConfirmCart extends HttpServlet 
{
  
    //Defines Info
    private String bgcolor     = "FBF8E8"; 
    private String infoURL     = "http://www.paintingwithasaw.com:8080/PaintSaw/submitform.jsp" ;
    private String editPic     = "http://www.paintingwithasaw.com/images/edit.gif" ;
    private String viewCart    = "http://www.paintingwithasaw.com:8080/PaintSaw/dispCart.jsp" ;
    
    private String submitPic   = "http://www.paintingwithasaw.com/images/submit.gif" ;
    private String orderURL    = "http://www.paintingwithasaw.com:8080/PaintSaw/EmailCart" ;
    
    private float[]     rates    = { 3,5,
                                    (float)6.5,10,
                                    15,17,
                                    20} ;
                                    
    private String      state           ;
    
    //On Get - Query Database
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        //Vars
        DataSource  ds            ;
        Connection  con           ;
        Context     cxt           ;

        int         count   = 0   ;
        
        Statement stmt		  ;
        Statement stmt2		  ;
        HttpSession session = request.getSession(true);

        //Initialize Page Writer
        ResourceBundle rb ;
        ResourceBundle.getBundle("LocalStrings",request.getLocale());
        response.setContentType("text/html")  ;
        PrintWriter out = response.getWriter();

        //Open Connection to Database
	try 
	{
            cxt = new InitialContext(); 
            Context envCtx = (Context) cxt.lookup("java:comp/env");
            ds = (DataSource) envCtx.lookup("jdbc/PaintSawDB");

            con   = ds.getConnection()   ; 
            stmt  = con.createStatement();
            stmt2 = con.createStatement();
        }
        catch(NamingException e) 
	{
            out.println(e.getMessage()) ;
            return ;
	}
        catch(SQLException ex) 
	{
            out.println(ex.getMessage()) ;
            return ;
        }
                
        //Main ------------------------------------------------------
        
        //Out Put Page Headers
        String head = "<HTML><TITLE>Confirmation Page</TITLE><BODY bgcolor=" + bgcolor + 
                      " style=\"font-family: Monotype Corsiva\"><CENTER>" ;
               head += "<TABLE WIDTH=\"75%\">" ;
               head += "<TR ALIGN=left bgcolor=#cccc99>\n" ;
               head += "<TD COLSPAN=2><B><FONT SIZE=3>Customer Information:</FONT></B></TD>"     ;
               head += "<TD valign=center align=center width=40>" +
                       "<a href=\"" + infoURL + "\">" +
                       "<img border=0 src=\"" + editPic + "\">" +
                       "</a></TD>" ; 
               head += "</TR>\n" ; 
        
        out.print(head) ; 
        
        //Submit Parameters
        out.print(processParameters(request, stmt, session)) ;
        
        //Print out the Customer Information From Database
        out.print(getCustomerInfo(session, stmt, stmt2)) ;
        
        //Start Table For Items
        head = "</TABLE> <BR>" ;
        head += "<TABLE WIDTH=75%>\n" ;
        head += "<TR ALIGN=center bgcolor=#cccc99>\n" ;
        head += "<TD><B>Item:</B></TD>"     ;
        head += "<TD><B>Name:</B></TD>"     ;
        head += "<TD><B>Qty:</B></TD>"      ;
        head += "<TD><B>Wood:</B></TD>"     ;
        head += "<TD><B>Clock:</B></TD>"    ;
        head += "<TD><B>Price:</B></TD>"    ;
        head += "<TD valign=center align=center>" +
                "<a href=\"" + viewCart + "\">" +
                "<img border=0 src=\"" + editPic + "\">" +
                "</a></CENTER></TD>" ; 
        head += "</TR>\n" ; 
        
        out.print(head) ; 
            
        //Get All the Pictures and Get a count
        String q1 = "SELECT SessionTable.*, pics.price, pics.name FROM SessionTable, pics WHERE SessionTable.item = pics.dex AND SessionTable.sessionID='" + 
                    session.getId() + "' ORDER BY SessionTable.item" ;
        try 
	{
            //Print Params
            ResultSet result = stmt.executeQuery(q1);
	   
            //Loop Over Items Purchased
            while(result.next())
            {
                out.print("<TR align=center>\n\t<TD>" + result.getString("item") + "</TD>\n"); 
                out.print("\t<TD>" + result.getString("name") + "</TD>\n"); 
                out.print("\t<TD>" + result.getString("quantity") + "</TD>\n"); 
                out.print("\t<TD>" + result.getString("wood") + "</TD>\n") ; 
                out.print("\t<TD>" + getClock(result.getString("clock"), stmt2) + "</TD>\n"); 
                out.print("\t<TD>" + result.getString("price") + "</TD>\n");
                out.print("<TD></TD></TR>"); 
              
                //Count Items Bought
                count++ ;
            }//end loop through purchased items
            
            //Append Subtotal
            NumberFormat nf = NumberFormat.getCurrencyInstance() ;
            
            float subtotal = getSubTotal(result) ;
            float rate     = getRate(subtotal)   ;
            float tax      = getTax(subtotal, state)   ;
            
            String price  = "<TR><TD COLSPAN=4></TD>" +
                   "<TD><p align=right><B>SubTotal:<BR>Shipping:<BR>Tax:<BR>Total:</B></p>" +
                   "<TD align=center><B>" ;
                   price += nf.format(subtotal) + "<BR>" ;
                   price += nf.format(rate)     + "<BR>" ;
                   price += nf.format(tax)      + "<BR>" ;
                   price += nf.format(subtotal + rate + tax) + "<BR>" ;
                   price += "</B></TD><TD></TD></TR>"    ;
                   
            out.print(price) ;
            
            //Close Lookup
            result.close();
                      
         }//end try
         catch(SQLException ex) 
	 {
            out.println("SQLException: ");
            out.println(ex.getMessage());
         }

        //Check for nothing bought
        if(count == 0)
        {
            out.print("<TR><TD COLSPAN=7><H3> No Items Were Requested.<BR>" + 
                      "Please select at least one item to proceed. </H3></TD></TR>") ; 
            
            out.print("</CENTER></TABLE></BODY></HTML>") ;
        }
        else
        {
            out.print("</CENTER></TABLE></BODY></HTML>") ;
            
            //Output Ending of HTML Page
             head = "<CENTER><TABLE WIDTH=75%><TR><TD WIDTH=50%></TD>" + 
                    "<TD valign=center align=right>" +
                    "<a href=\"" + orderURL + "\">" +
                    "<img border=0 src=\"" + submitPic + "\">" +
                    "</a></TD><TD width=40></TD></TR></TABLE><CENTER>" ; 
        
            out.print(head) ;
        }
        
        //Close Out Everything that was opened
        try
	{
                if(cxt != null)
                    cxt.close() ;
                if(stmt2 != null)
                    stmt2.close();
                if(stmt != null)
                    stmt.close();
        	if(con != null)
                    con.close() ;
	}
        catch(javax.naming.NamingException nx)
        {
            //Do Nothing
        }
        catch(SQLException ex) 
	{
		//Do nothing we are exiting
	}

    }//end doGet

    //////////////////////////////////////////////////////////////////
    //Get Subtotal
     public float getSubTotal(ResultSet sessRes)
    {
        float subtotal = 0 ; 
        
        try
        {
            if(!sessRes.first())
                return 0 ; 
            
            //Loop over Items Summing Prices
            do
            {
                //Get Price and Clean it up
                String price = sessRes.getString("price") ; 
                price = price.trim() ; 
                price = price.replace('$', '0') ;
                
                if(price.indexOf(',') >= 0)
                {
                    price = (price.split(","))[0] ; 
                }
                
                //Parse Out Price and Multiple by Count
                float temp = Float.parseFloat(price) ; 
                temp *= sessRes.getInt("quantity") ; 
                
                subtotal += temp ; 
                
            }while(sessRes.next()) ; //end loop
            
            return subtotal ;
        }
        catch(SQLException ex)
        {
            return -1 ;
        }
        
    }//end get SubTotal
    
    //////////////////////////////////////////////////////////////////
    //Get Tax
    private float getTax(float x, String state)
    {
        if(state.compareToIgnoreCase("nm") == 0)
            return x * (float)0.058215 ; 
        else
            return 0 ;
    }
    
    ////////////////////////////////////////////////////////////
    public float getRate(float x)
    {
        if( x <= 0)
            return 0 ;
        else if(x <= 15)
            return rates[0] ;
        else if(x <= 30)
            return rates[1] ; 
        else if(x <= 50)
            return rates[2] ; 
        else if(x <= 75)
            return rates[3] ; 
        else if(x <= 100)
            return rates[4] ; 
        else if(x <= 125)
            return rates[5] ; 
        else
            return rates[6] ; 

     }//end getRate
       
    ///////////////////////////////////////////////////////////////////
    //Return a String For the Clock Input
    private String getClock(String clock, Statement stmt)
    {
        if(clock.compareToIgnoreCase("-1") == 0)   
        {
            return "No Clock" ; 
        }
        else if(clock.compareToIgnoreCase("-2") == 0)   
        {
            return "Clock as Pictured" ;
        }
       
        try
        {
            ResultSet res = stmt.executeQuery("SELECT * FROM clocks WHERE dex=" +
                                                 clock) ;
        
            //For Empty Lookups
            if(res.first())
            {
                String ret = res.getString("size") + " " + res.getString("face") +
                             " w/ " + res.getString("numerals") + " Numerals</OPTION>\n" ;
                
                res.close() ;
                return ret  ;
            }
            else
            {
                res.close() ;
                
                return "Invalid Clock!" ;
            }
        }
        catch(SQLException ex)
        {
           return "Clock Database Error";  
        }

    } //end clock input
    
     //////////////////////////////////////////////////////////////
     //Load the Parameters into the Database
     private String processParameters(HttpServletRequest request, Statement stmt,
                                   HttpSession session)
     {
        Enumeration items = request.getParameterNames() ;
        
        java.sql.Date created = new java.sql.Date(session.getCreationTime());

        String dateFormat = "yyyy-MM-dd hh-mm-ss";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        String ret    = "" ; 
        String values = " VALUES ('" + session.getId() + "','"
                                     + sdf.format(created) + "'," ;
        //No Elements, do nothing
        if(!items.hasMoreElements())
            return "" ; 
        
        String query = "INSERT INTO CustomerInfo (sessionid, sessCreated, "; 
        
        //Loop over parameters to dump out
        while(items.hasMoreElements())
        {
            String str    = (String) items.nextElement() ; 
            
            if(str.startsWith("submit"))
                continue ;
            
            //Get the Values of the Name
            String temp[] = request.getParameterValues(str) ; 
            String value  = temp[0] ;  
            
            //Remove Chars that will destory syntax
            value = value.replace('\'', '\"') ;
            value = value.replace(')', ']') ;
            value = value.replace('(', '[') ;
            
            //Build Insert String
            query  += str ; 
            values += "'" + value + "'"  ;
                
            if(items.hasMoreElements())
            {
                query  += ", " ;
                values += ","  ; 
            }
            
        }//end loop

        query += ")" + values + ")" ; 
            
        //Try Updating the Item
        try
        {
            String delQuery = "DELETE FROM CustomerInfo WHERE sessionID = '" + session.getId() + "'" ;
            
            //Delete Existing Session Information
            stmt.executeUpdate(delQuery) ;
            
            //Insert New Session Information
            stmt.executeUpdate(query) ;
        }
        catch(SQLException ex)
        {
           return ex.getMessage() ; 
        }

        return "" ;
     }//end ProcessParameters
     
     /////////////////////////////////////////////////////////////////////
     //Returns a String of Customer Information
     private String getCustomerInfo(HttpSession session, Statement stmt, Statement stmt2)
     {
         ResultSet  res     ;
         ResultSet  fields  ;
         String     ret = "";
         
         String query = "SELECT * FROM CustomerInfo WHERE sessionid = '" +
                        session.getId() + "'" ;
         try 
         {
             res    = stmt.executeQuery(query) ;
             fields = stmt2.executeQuery("DESCRIBE CustomerInfo") ;
             
             if(!res.first())
             {
                 return "SQLException: No Customer Information Available." ; 
             }

            //Else - Loop Through Pushing out Table
            while(fields.next())
            {   
                String str  = fields.getString("Field") ;
                String name = str.replace('_', ' ') ;
             
                if(str.compareToIgnoreCase("sessionid") == 0 || 
                   str.compareToIgnoreCase("index") == 0 || 
                   str.compareToIgnoreCase("sessCreated") == 0)
                    continue ;
                
                if(name.compareToIgnoreCase("state") == 0)
                    state = res.getString(str) ;
                
                ret += "<TR><TD><B>" + name + ":</B></TD><TD>" + 
                                       res.getString(str) + 
                                       "</TD></TR>\n" ; 
            }//end loop
         
             fields.close(); 
             res.close();
             
         }//end try
         catch(SQLException ex)
         {
            return ex.getMessage() ; 
         }
         
         return ret ; 
     }//end getCustomerInfo
     
}//end class def
