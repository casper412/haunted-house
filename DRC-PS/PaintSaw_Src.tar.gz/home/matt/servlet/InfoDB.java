/* Database Interface for Pictures Database by Matthew Hall
 *
 */

package Database        ;

import javax.sql.*      ;
import java.sql.*       ;
import javax.naming.*   ;
import javax.servlet.*;
import javax.servlet.http.*;
import java.text.SimpleDateFormat ;
import java.util.* ; 

public class InfoDB
{
    private DataSource  ds              ;
    private Connection  con             ;
    private Context     cxt             ;
    private int         m_init		;
    private Statement   sessStmt        ;
    private ResultSet   sessRes         ;
    
    private HttpServletRequest request  ;
    
    private String temp     ;
    private String jspURL      = "http://www.paintingwithasaw.com:8080/PaintSaw/dispCart.jsp" ;

    //On Init - Open SawPictures Database
    public void Init(HttpServletRequest res)
    {
	m_init = 0 ;
        request = res ;

	try 
	{
            cxt = new InitialContext(); 
            Context envCtx = (Context) cxt.lookup("java:comp/env");
            ds = (DataSource) envCtx.lookup("jdbc/PaintSawDB");

            con  = ds.getConnection()   ; 
            sessStmt = con.createStatement();

            envCtx.close() ;
            
        }
        catch(NamingException e) 
	{
		m_init = 2 ;
                temp = e.getMessage() ; 
	}
        catch(SQLException ex) 
	{
		m_init = 1 ;
                temp = ex.getMessage() ; 
        }
        
    }//end init
    
    //On Close - Close Connection
    public void Close()
    {
	try
	{
                if(con != null)
                {
                    con.close() ;
                    con = null  ;
                }
                            
                if(sessStmt != null)
                {
                    sessStmt.close();
                    sessStmt = null ;
                }
                if(sessRes != null)
                {
                    sessRes.close();
                    sessRes = null ;
                }

	}
        catch(SQLException ex) 
	{
		//Do nothing we are exiting
	}

        if(cxt != null)
        {
            try
            {
                cxt.close() ;
                cxt = null  ;
            }
            catch(javax.naming.NamingException ex)
            {
                //Do Nothing we are exiting
            }
         }
        
    }//end destroy
    
    //Query Database
    public String doQuery()
    {     
        //Check that Init was called
        if(m_init > 0)
        {
            return temp ;
        }
        
        //Init
        HttpSession session = request.getSession(true);

        //Join the SessionTable with the Pics table for the URLs and Prices
        String query = "SELECT * FROM CustomerInfo WHERE sessionid ='" + 
                        session.getId() + "'";
        try 
	{
            //Load Items Bought
            sessRes = sessStmt.executeQuery(query);
            
            if(!sessRes.first())
            {
                m_init = 5 ; 
            }
	} 
       	catch(SQLException ex) 
	{
           m_init = 4 ;
           return "SQL Exception: " + ex.getMessage() ;
        }

        return "" ; 
        
    } //end do Query
    
    ////////////////////////////////////////////////////////////////////
   public String getProp(String name)
    {
        if(name == null || m_init > 0 )
            return "" ;
        
        try
        {
            return sessRes.getString(name) ; 
        }
        catch(SQLException ex) 
	{
            return "SQLException: " + ex.getMessage() ;
        }
       
    }//end get Prop
    
}//end class def
