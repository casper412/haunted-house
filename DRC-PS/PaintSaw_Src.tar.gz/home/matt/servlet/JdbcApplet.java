/* Decompiled by Mocha from JdbcApplet.class */
/* Originally compiled from JdbcApplet.java */

import java.awt.*;
import java.sql.*;
import java.applet.Applet;

public synchronized class JdbcApplet extends Applet
{
    static final String driver_class = "oracle.jdbc.driver.OracleDriver";
    static final String connect_string = "jdbc:oracle:thin:scott/tiger@dlsun511:1721:dbms733";
    static final String query = "select 'Hello JDBC: ' || sysdate from dual";
    Button execute_button;
    TextArea output;
    Connection conn;

    public void init()
    {
        setLayout(new BorderLayout());
        Panel panel = new Panel();
        panel.setLayout(new FlowLayout(0));
        execute_button = new Button("Hello JDBC");
        panel.add(execute_button);
        add("North", panel);
        output = new TextArea(10, 60);
        add("Center", output);
    }

    public boolean action(Event event, Object object)
    {
        if (event.target != execute_button)
            return false;
        try
        {
            output.setText(null);
            if (conn == null)
            {
                output.appendText("Loading JDBC driver oracle.jdbc.driver.OracleDriver\n");
                Class.forName("oracle.jdbc.driver.OracleDriver");
                output.appendText("Connecting to jdbc:oracle:thin:scott/tiger@dlsun511:1721:dbms733\n");
                conn = DriverManager.getConnection("jdbc:oracle:thin:scott/tiger@dlsun511:1721:dbms733");
                output.appendText("Connected\n");
            }
            Statement statement = conn.createStatement();
            output.appendText("Executing query select 'Hello JDBC: ' || sysdate from dual\n");
            for (ResultSet resultSet = statement.executeQuery("select 'Hello JDBC: ' || sysdate from dual"); resultSet.next(); )
                output.appendText(new StringBuffer(String.valueOf(resultSet.getString(1))).append("\n").toString());
            output.appendText("done.\n");
        }
        catch (Exception e)
        {
            output.appendText(new StringBuffer(String.valueOf(e.getMessage())).append("\n").toString());
        }
        return true;
    }

    public JdbcApplet()
    {
    }
}
