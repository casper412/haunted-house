/* Dynamic Menu by Matthew Hall
 *
 */

import javax.sql.*      ;
import java.sql.*       ;
import javax.naming.*   ;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Thumbs extends HttpServlet 
{
  
    //Defines Info
    private String bgcolor     = "FBF8E8"; 
    private String servURL     = "http://www.paintingwithasaw.com:8080/PaintSaw/Thumbs" ;
    private String displayURL  = "http://www.paintingwithasaw.com:8080/PaintSaw/dispPic.jsp";
    private String cartURL     = "http://www.paintingwithasaw.com:8080/PaintSaw/dispCart.jsp?add=";
    private String addPicURL   = "http://www.paintingwithasaw.com/images/add.gif" ;
    
    //On Get - Query Database
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        
        DataSource  ds            ;
        Connection  con           ;
        Context     cxt           ;
   
        Statement stmt		;
    
        //Vars
        String category  ;
        String pos       ;
        String epos      ;
        String ecategory ;
        String sp        ;
        String ep        ;
        long   cat       ;
        long   catPos    ;
        long   startPage ;
        long   endPage   ;
        long   cPos      ;
        long   ec        ;
        
        //Initialize Page Writer
        ResourceBundle rb ;
        ResourceBundle.getBundle("LocalStrings",request.getLocale());
        response.setContentType("text/html")  ;
        PrintWriter out = response.getWriter();
        
        //Open Connection to Database
	try 
	{
            cxt = new InitialContext(); 
            Context envCtx = (Context) cxt.lookup("java:comp/env");
            ds = (DataSource) envCtx.lookup("jdbc/PaintSawDB");

            con  = ds.getConnection()   ; 
            stmt = con.createStatement();

        }
        catch(NamingException e) 
	{
            out.println("Initialization Failed") ;
            return ;
	}
        catch(SQLException ex) 
	{
            out.println("Initialization Failed") ;
            return ;
        }
                
        //Main
               
        //Get Parameters
        pos     = request.getParameter("pos"        ) ;
        category= request.getParameter("category"   ) ;
        sp      = request.getParameter("sp"         ) ;
        ep      = request.getParameter("ep"         ) ;
        
        if(category == null)
        {
            out.println("Category Parameter is Invalid!") ;
            return ;
        }
        
        cat = Long.parseLong(category) ;
        
        if(pos == null || ((catPos = Long.parseLong(pos)) - 1) % 10 != 0)
        {
            pos     = Long.toString(cat + 1) ;
            catPos  = cat + 1   ;
        }
        
        ec        = catPos + 10 ;
        ecategory = Long.toString(cat + 1000) ;

        //Ensure we are not getting funny parameters
        if((ec - 1) % 10 != 0)
            ec = cat + 11 ;
        
        cPos = (ec - cat) / 10 ;
        
        //If the start page or end page is null, 
        //figure out how many pages are needed
        startPage = 1;
        endPage   = 1;
            
        if(sp == null || ep == null)
        {
            //Get All the Pictures and Get a count
            String q1 = "SELECT * FROM pics WHERE (dex >= " + category +
                        ") and (dex < " + ecategory + ")";
            try 
	    {
		    //Print Params
                    startPage = 1;
         
            	    ResultSet result = stmt.executeQuery(q1);
	            result.last() ;
                    endPage = result.getRow() / 10 ; 
                    
                    //Account for spare pictures on last page
                    if((result.getRow() % 10) != 0)
                        endPage += 1 ;
                    
                    result.close();
             }
             catch(SQLException ex) 
	     {
           	    out.println("SQLException: ");
            	    out.println(ex.getMessage());
             }
        }
        else
        {
            startPage = Long.parseLong(sp) ;
            endPage   = Long.parseLong(ep) ; 
        }
        
        //Start HTML Output
        String outHead =  "<HTML><HEAD>\n" ;
               outHead += "<style type=\"text/css\">\n" ; 
               outHead += "<!--\n" ; 
               outHead += "a:link    { text-decoration: none; color=\"000000\"}\n" ;
               outHead += "a:visited { text-decoration: none; color=\"000000\"}\n" ;
               outHead += "a:hover   { text-decoration: none; color=\"0000FF\"}\n" ;
               outHead += "-->\n" ;
               outHead += "</style>\n" ;
        
        out.println(outHead) ;
        
        out.println("</HEAD>\n<BODY link=\"#000000\" vlink=\"#000000\" alink=\"#0000FF\"" +
                    "bgcolor=\"" + bgcolor + "\" style=\"font-family: Monotype Corsiva\">\n") ; 
   
        //Print a Table to hold all tables to make adjustments to placement
        out.println("<CENTER><TABLE BORDER=0>\n") ;
        
        if(category.compareToIgnoreCase("23000") == 0)
        {
            outHead = "<TR><TD align=center>"  +
                      "Pieces Made From Burls May be a Different Size Or <BR>" +
                      "Look Different Than Pictured Depending On Wood Availablity." +
                      "</TD></TR>\n" ;
            
            out.print(outHead) ;
        }
        
        out.println("<TR><TD align=center>") ;
        out.println(GetPageNumbers(startPage, endPage, ec, cPos, category)) ;
        out.println("</TD></TR><TR><TD>\n") ;
        
	//Load All Pictures
        String query = "SELECT * FROM pics WHERE (dex >= " + pos +
                       ") and (dex < " + Long.toString(ec) + ") ORDER BY dex";

        try 
	{
            //Print Params
            ResultSet result = stmt.executeQuery(query);
	    while (result.next()) 
            {
                
                String name = "<table width=100%><TR><TD>" ; 
                name += "<table width=100% border=0>\n"       ;    
                name += "<TR>\n\t<TD ROWSPAN=3 align=left>"         ;
                name += "<a style=\"text-decoration: none\" href=\"" + 
                        displayURL + "?pic=" + result.getString(1) + "\">" ;
                name += "<img border=0 src=\"" + result.getString(3) + "\">" ;
                name += "</a>"                                      ;
                
                //Text Under Picture
                name += "<BR><FONT SIZE=2>"                 +
                        "Click Image For More Details"      +
                        "</FONT>" ;
                
                name += "</TD>\n\t<TD align=right>"                 ;
                name += "<font size=4><b>"                          ;
                name += "<a style=\"text-decoration: none\" href=\"" + 
                        displayURL + "?pic=" + result.getString(1) + "\">" ;
                name += result.getString(4)                         ;
                name += "</a>"                                      ;
                name += "</b></font></TD>\n"                        ;
                name += "<TR>\n\t<TD align=right>"                  ;
                name += "<font size=3>"                             ;   
                name += result.getString(5)                         ;
                name += "</font></TD>\n</TR>\n"                     ;
                name += "<TR>\n\t<TD align=right>"                  ;
                name += "<font size=3>"                             ;
                name += result.getString(7)                         ;
                name += "</font></TD>\n</TR>\n"                     ;               
                name += "</table>\n\n"                              ;
                    
                //Add to Cart Column
                name += "</TD><TD><table width=100% border=0>"       ; 
                name += "<TD align=right>\n"                        ;
                name += "<a href=\"" + cartURL + result.getString("dex") + "\">" +
                        "<img border=0 src=\"" + addPicURL + "\">" + 
                        "</a>"                                      ;
                name += "</TD></TR></TABLE>\n"                      ;
                name += "</TD></TR></TABLE>\n"                      ;
                
	        out.println(name);
            }//end while

 	} 
       catch(SQLException ex) 
       {
           out.println("SQLException: ");
           out.println(ex.getMessage());
       }
        
        out.println("</TD></TR>") ;
        out.println("<TR><TD align=center>") ;
        
        out.println(GetPageNumbers(startPage, endPage, ec, cPos, category)) ;

        out.println("</TD></TR></TABLE></CENTER>") ;
        out.println("</body>");
        out.println("</html>");
        
        //Close Out Everything that was opened
        try
	{
                if(cxt != null)
                    cxt.close() ;
        	if(stmt != null)
                    stmt.close();
        	if(con != null)
                    con.close() ;
	}
        catch(javax.naming.NamingException nx)
        {
            //Do Nothing
        }
        catch(SQLException ex) 
	{
		//Do nothing we are exiting
	}

    }//end doGet

    //////////////////////////////////////////////////////////////////
    private String GetPageNumbers(long startPage, long endPage, 
                                  long ec, long cPos,
                                  String category)
    {
        //Don't print a single one because it sucks
        if(startPage == endPage)
            return "" ;
        
        String buildLink = "" ;
        
        //Print Page Numbers and Previous and Next
        //Print Previous
        if(cPos != 1) {
            buildLink = "<a href=\"" + servURL +
            "?category=" + category +
            "&sp="  + Long.toString(startPage) +
            "&ep="  + Long.toString(endPage) +
            "&pos=" + Long.toString(ec - 20) +
            "\"> <img border=0 src=\"http://www.paintingwithasaw.com/images/previous.gif\"></a>" ;
        }
        
        //Print Next
        if(cPos != endPage) {
            buildLink += "<a href=\"" + servURL +
            "?category=" + category +
            "&sp="  + Long.toString(startPage) +
            "&ep="  + Long.toString(endPage) +
            "&pos=" + Long.toString(ec) ;
  
            buildLink += "\"> <img border=0 src=\"http://www.paintingwithasaw.com/images/next.gif\"> </a>" ;
        }
        
        buildLink += "<BR>\n" ;
        
         //Print Out Pages Underneath
        for(long si = startPage ; si <= endPage ; si++) {
            long pagePos = ec - ((cPos - si + 1) * 10) ;
           
            buildLink += "<a href=\"" + servURL +
            "?category=" + category             +
            "&sp="  + Long.toString(startPage)  +
            "&ep="  + Long.toString(endPage)    +
            "&pos=" + Long.toString(pagePos)    ;
            if(si == cPos)
                buildLink += "\"> <B>"  + Long.toString(si) + "</B></a>";
            else
                buildLink += "\"> "  + Long.toString(si) + "</a>";
        }
        
        return buildLink ;
        
    }//end print page numbers

}//end class def
