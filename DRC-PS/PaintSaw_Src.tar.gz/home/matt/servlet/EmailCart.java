/* Dynamic Menu by Matthew Hall
 *
 */

import javax.sql.*      ;
import java.sql.*       ;
import javax.naming.*   ;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.text.NumberFormat ;
import email.* ;

public class EmailCart extends HttpServlet 
{
    //Defines Info
    private String bgcolor     = "FBF8E8"; 
    
    private float[]     rates    = { 3,5,
                                    (float)6.5,10,
                                    15,17,
                                    20} ;
                                    
    private String      state           ;
    
    //On Get - Query Database
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        //Vars
        DataSource  ds            ;
        Connection  con           ;
        Context     cxt           ;
        
        int         count   = 0   ;
        
        Statement stmt		  ;
        Statement stmt2		  ;
        HttpSession session = request.getSession(true);

        //Initialize Page Writer
        ResourceBundle rb ;
        ResourceBundle.getBundle("LocalStrings",request.getLocale());
        response.setContentType("text/html")  ;
        PrintWriter out = response.getWriter();
        
        //Init Useful Info about the Email
       	String from     = "sales@paintingwithasaw.com"; 
	String to       = "sales@paintingwithasaw.com"; 
	String subject  = "-- Painting With A Saw Email Order --";
	String body     = "";

        //Open Connection to Database
	try 
	{
            cxt = new InitialContext(); 
            Context envCtx = (Context) cxt.lookup("java:comp/env");
            ds = (DataSource) envCtx.lookup("jdbc/PaintSawDB");

            con   = ds.getConnection()   ; 
            stmt  = con.createStatement();
            stmt2 = con.createStatement();

        }
        catch(NamingException e) 
	{
            out.println(e.getMessage()) ;
            return ;
	}
        catch(SQLException ex) 
	{
            out.println(ex.getMessage()) ;
            return ;
        }
                
        //Main ------------------------------------------------------
        
        //Out Put Page Headers
        String head = "<HTML><TITLE>Confirmation Page</TITLE><BODY bgcolor=" + bgcolor + 
                      " style=\"font-family: Monotype Corsiva\"><CENTER>" ;
        out.print(head) ;
        
        long orderNum = 0 ;
        
        try
        {
            //Get Order Number
            ResultSet set = stmt.executeQuery("SELECT orderNum FROM orderNumber") ;
            
            if(!set.first())
                orderNum = -1 ;
            else
                orderNum = set.getLong("orderNum") ;
            
            set.close() ; 
            
            orderNum = orderNum + 1;
            
            //Set the next value
            stmt.executeUpdate("UPDATE orderNumber SET orderNum = '" + 
                                Long.toString(orderNum) + "'") ;
        }
        catch(SQLException ex) 
	{
            out.println(ex.getMessage()) ;
        }
        
        //Print Confirmation Message and Get Order Number Etc.
        head = "<BR><BR><B>Your Order has been sent.</B> <BR>Your Order Number is " +
               Long.toString(orderNum) + ". Thank you for visiting " +
               "www.paintwithasaw.com.<BR><BR>" ;
        out.print(head) ; 
        
        ///////////////////////////
        //Add Order Number to Email
        body += "Order Number:\t" + Long.toString(orderNum) + "\n" ; 
        
        ///////////////////////
        //Print Customer Info
        
        head = "<TABLE WIDTH=\"75%\">" ;
        head += "<TR ALIGN=left bgcolor=#cccc99>\n" ;
        head += "<TD COLSPAN=2><B><FONT SIZE=3>Customer Information:</FONT></B></TD>"     ;
        head += "</TR>\n" ; 
        out.print(head) ; 
        
        out.print(getCustomerInfo(session, stmt, stmt2)) ;
        
        //Start Table For Items
        head = "</TABLE> <BR>" ;
        head += "<TABLE WIDTH=75%>\n" ;
        head += "<TR ALIGN=center bgcolor=#cccc99>\n" ;
        head += "<TD><B>Item:</B></TD>"     ;
        head += "<TD><B>Name:</B></TD>"     ;
        head += "<TD><B>Qty:</B></TD>"      ;
        head += "<TD><B>Wood:</B></TD>"     ;
        head += "<TD><B>Clock:</B></TD>"    ;
        head += "<TD><B>Price:</B></TD>"    ;
        head += "</TR>\n" ; 
        
        out.print(head) ; 
        
        body   += "\n\nItems Requested: \n" ; 
            
        //Get All the Pictures and Get a count
        String q1 = "SELECT SessionTable.*, pics.price, pics.name FROM SessionTable, pics WHERE SessionTable.item = pics.dex AND SessionTable.sessionID='" + 
                    session.getId() + "' ORDER BY SessionTable.item" ;
        try 
	{
            //Print Params
            ResultSet result = stmt.executeQuery(q1);
	   
            //Loop Over Items Purchased
            while(result.next())
            {
                String clock = getClock(result.getString("clock"), stmt2) ;
                
                out.print("<TR align=center>\n\t<TD>" + result.getString("item") + "</TD>\n"); 
                out.print("\t<TD>" + result.getString("name") + "</TD>\n"); 
                out.print("\t<TD>" + result.getString("quantity") + "</TD>\n"); 
                out.print("\t<TD>" + result.getString("wood") + "</TD>\n"); 
                out.print("\t<TD>" + clock + "</TD>\n"); 
                out.print("\t<TD>" + result.getString("price") + "</TD>\n</TR>"); 
                
                body += "Item:\t\t" + result.getString("item") + "\n" ;  
                body += "Item:\t\t" + result.getString("name") + "\n" ;  
                body += "Quantity:\t\t" + result.getString("quantity") + "\n" ;  
                body += "Wood:\t\t" + result.getString("wood") + "\n" ;  
                body += "Clock:\t\t" + clock + "\n" ;  
                body += "Price:\t\t" + result.getString("price")  + "\n\n" ;  
              
                //Count Items Bought
                count++ ;
            }//end loop through purchased items
            
           //Append Subtotal
            NumberFormat nf = NumberFormat.getCurrencyInstance() ;
            
            float subtotal = getSubTotal(result) ;
            float rate     = getRate(subtotal)   ;
            float tax      = getTax(subtotal, state)   ;
            
            String price  = "<TR><TD COLSPAN=4></TD>" +
                   "<TD><p align=right><B>SubTotal:<BR>Shipping:<BR>Tax:<BR>Total:</B></p>" +
                   "<TD align=center><B>" ;
                   price += nf.format(subtotal) + "<BR>" ;
                   price += nf.format(rate)     + "<BR>" ;
                   price += nf.format(tax)      + "<BR>" ;
                   price += nf.format(subtotal + rate + tax) + "<BR>" ;
                   price += "</B></TD><TD></TD></TR>"    ;
                   
            out.print(price) ;
            
            body += "Subtotal:\t" + nf.format(subtotal) + "\n" ; 
            body += "Shipping:\t" + nf.format(rate)     + "\n" ; 
            body += "Tax:\t"      + nf.format(tax)      + "\n" ; 
            body += "Total:\t"    + nf.format(subtotal + rate + tax) + "\n" ; 
            
            //Close Lookup
            result.close();
            
            //Clear database for this session
            //and all old sessions
            String dateFormat = "yyyy-MM-dd hh-mm-ss";
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            
            Calendar cal = new GregorianCalendar();
            cal.add(cal.DATE, -90) ; 
            java.util.Date oldDate = cal.getTime() ;
           
            //Clear SessionTable
            q1  = "DELETE FROM SessionTable WHERE sessionID='" + session.getId() + "'" ;
            q1 += " OR sessCreated < '" + sdf.format(oldDate) + "'"; 
            
            stmt.executeUpdate(q1) ; 
            
            //Clear CustomerInfo
            q1  = "DELETE FROM CustomerInfo WHERE sessionID='" + session.getId() + "'" ;
            q1 += " OR sessCreated < '" + sdf.format(oldDate) + "'"; 
            
            stmt.executeUpdate(q1) ; 
            
         }//end try
         catch(SQLException ex) 
	 {
            out.println("SQLException: ");
            out.println(ex.getMessage());
         }

        //Check for nothing bought
        if(count == 0)
        {
            out.print("<TR><TD COLSPAN=6><H3> No Items Were Requested.<BR>Please select at least one item to proceed. </H3></TD></TR>") ;  
        }
        else
        {
            //Append The Requesters Info
            body += "\n\nRemote Address:\t" + request.getRemoteAddr() + "\n";
            body += "Remote Host:\t" + request.getRemoteHost() + "\n" ;
            body += "Remote User:\t" + request.getRemoteUser() + "\n" ;
        
            //Send the Actual Email to Order Taker
            SendEmail mailer = new SendEmail() ; 
            mailer.SendEmailTo(from, to, subject, body);
        
        }
        
        //Output Ending of HTML Page
        out.print("</CENTER></TABLE></BODY></HTML>") ;

        //Close Out Everything that was opened
        try
	{
                if(cxt != null)
                    cxt.close() ;
        	if(stmt != null)
                    stmt.close();
                if(stmt2 != null)
                    stmt.close();
        	if(con != null)
                    con.close() ;
	}
        catch(javax.naming.NamingException nx)
        {
            //Do Nothing
        }
        catch(SQLException ex) 
	{
		//Do nothing we are exiting
	}

    }//end doGet

    ///////////////////////////////////////////////////////////////////
    //Return a String For the Clock Input
    private String getClock(String clock, Statement stmt)
    {
        if(clock.compareToIgnoreCase("-1") == 0)   
        {
            return "No Clock" ; 
        }
        else if(clock.compareToIgnoreCase("-2") == 0)   
        {
            return "Clock as Pictured" ;
        }
       
        try
        {
            ResultSet res = stmt.executeQuery("SELECT * FROM clocks WHERE dex=" +
                                                 clock) ;
        
            //For Empty Lookups
            if(res.first())
            {
                String ret = res.getString("size") + " " + res.getString("face") +
                             " w/ " + res.getString("numerals") + " Numerals</OPTION>\n" ;
                
                res.close() ;
                return ret  ;
            }
            else
            {
                res.close() ;
                
                return "Invalid Clock!" ;
            }
        }
        catch(SQLException ex)
        {
           return "Clock Database Error";  
        }

    } //end clock input
    
    //////////////////////////////////////////////////////////////////
    //Get Subtotal
     public float getSubTotal(ResultSet sessRes)
    {
        float subtotal = 0 ; 
        
        try
        {
            if(!sessRes.first())
                return 0 ; 
            
            //Loop over Items Summing Prices
            do
            {
                //Get Price and Clean it up
                String price = sessRes.getString("price") ; 
                price = price.trim() ; 
                price = price.replace('$', '0') ;
                
                if(price.indexOf(',') >= 0)
                {
                    price = (price.split(","))[0] ; 
                }
                
                //Parse Out Price and Multiple by Count
                float temp = Float.parseFloat(price) ; 
                temp *= sessRes.getInt("quantity") ; 
                
                subtotal += temp ; 
                
            }while(sessRes.next()) ; //end loop
            
            return subtotal ;
        }
        catch(SQLException ex)
        {
            return -1 ;
        }
        
    }//end get SubTotal
    
    //////////////////////////////////////////////////////////////////
    //Get Tax
    private float getTax(float x, String state)
    {
        if(state.compareToIgnoreCase("nm") == 0)
            return x * (float)0.058215 ; 
        else
            return 0 ;
    }
    
    ////////////////////////////////////////////////////////////
    public float getRate(float x)
    {
        if( x <= 0)
            return 0 ;
        else if(x <= 15)
            return rates[0] ;
        else if(x <= 30)
            return rates[1] ; 
        else if(x <= 50)
            return rates[2] ; 
        else if(x <= 75)
            return rates[3] ; 
        else if(x <= 100)
            return rates[4] ; 
        else if(x <= 125)
            return rates[5] ; 
        else
            return rates[6] ; 

    }//end getRate
    
    /////////////////////////////////////////////////////////////////////
    //Returns a String of Customer Information
    private String getCustomerInfo(HttpSession session, Statement stmt, Statement stmt2)
    {
         ResultSet  res     ;
         ResultSet  fields  ;
         String     ret = "";
         
         String query = "SELECT * FROM CustomerInfo WHERE sessionid = '" +
                        session.getId() + "'" ;
         try 
         {
             res    = stmt.executeQuery(query) ;
             fields = stmt2.executeQuery("DESCRIBE CustomerInfo") ;
             
             if(!res.first())
             {
                 return "SQLException: No Customer Information Available." ; 
             }

            //Else - Loop Through Pushing out Table
            while(fields.next())
            {   
                String str  = fields.getString("Field") ;
                String name = str.replace('_', ' ') ;
             
                if(str.compareToIgnoreCase("sessionid")   == 0 || 
                   str.compareToIgnoreCase("sessCreated") == 0 ||
                   str.compareToIgnoreCase("index") == 0)
                    continue ;
                
                if(name.compareToIgnoreCase("state") == 0)
                    state = res.getString(str) ;
                
                ret += "<TR><TD><B>" + name + ":</B></TD><TD>" + 
                                       res.getString(str) + 
                                       "</TD></TR>\n" ; 
            }//end loop
         
             fields.close(); 
             res.close();
             
         }//end try
         catch(SQLException ex)
         {
            return ex.getMessage() ; 
         }
         
         return ret ; 
     }//end getCustomerInfo
     
}//end class def
