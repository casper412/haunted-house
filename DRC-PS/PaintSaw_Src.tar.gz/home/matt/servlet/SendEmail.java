package email ;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class SendEmail 
{
		private static final java.lang.String SMTP_HOST = "localhost";  

public SendEmail() 
{
	super();
}

public static void SendEmailTo(String from, String to, String subject, String text)
{
	try
	{
		// Get system properties
		Properties props = System.getProperties();

		// Setup mail server
		props.put("mail.smtp.host", SMTP_HOST);  //may need to Change this

		// Get session
		Session session = Session.getInstance(props, null);

		// Define message
		MimeMessage message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from));
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
		message.setSubject(subject);
		message.setText(text);

		// Send message
		Transport.send(message);
	}
	catch (Exception e)
	{
		System.out.println(e);
	}
}
}
