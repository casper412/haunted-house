/* Database Interface for Pictures Database by Matthew Hall
 *
 */

package Database        ;

import javax.sql.*      ;
import java.sql.*       ;
import javax.naming.*   ;

public class PicDB
{
    private DataSource  ds              ;
    private Connection  con             ;
    private Context     cxt             ;
    private int         m_init		;
    private Statement   stmt		;
    private ResultSet   result          ;

    //Defines Info
    private String bgcolor     = "FBF8E8" ; 

    //On Init - Open SawPictures Database
    public void Init()
    {
	m_init = 0 ;

	try 
	{
            cxt = new InitialContext(); 
            Context envCtx = (Context) cxt.lookup("java:comp/env");
            ds = (DataSource) envCtx.lookup("jdbc/PaintSawDB");

            con  = ds.getConnection()   ; 
            stmt = con.createStatement();

        }
        catch(NamingException e) 
	{
		m_init = 2 ;
	}
        catch(SQLException ex) 
	{
		m_init = 1 ;
        }
        
    }//end init
    
    //On Close - Close Connection
    public void Close()
    {
	try
	{
        	if(stmt != null)
                {
                    stmt.close();
                }
                if(con != null)
                {
                    con.close() ;
                }
	}
        catch(SQLException ex) 
	{
		//Do nothing we are exiting
	}

    }//end destroy
    
    //Query Database
    public String doQuery(String index)
    {     
        if(m_init > 0 || index == null)
        {
            return "Init Failed" ;
        }
        
        String query = "SELECT * FROM pics WHERE dex = " + index ;
        
        try 
	{
            result = stmt.executeQuery(query);
            if(!result.next())
            {
                m_init = 3; 
            }
            else
            {
                m_init = 0 ; 
            }
	} 
       	catch(SQLException ex) 
	{
           m_init = 4 ;
           return "SQL Exception: " + ex.getMessage() ;
        }
        
        return "" ;
        
    } //end do Query
    
    public String getPicProp(String name)
    {
        if(name == null || m_init > 0)
            return name ;
        
        try
        {
            return result.getString(name) ; 
        }
        catch(SQLException ex) 
	{
            return "SQLException: " + ex.getMessage() ;
        }
       
    }//end doGet

}//end class def
