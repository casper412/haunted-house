/************************************************/
/* Copyright 2003 DRC Solutions		*/
/************************************************/

function valid() 
{
  value = true;

  if (document.sForm.First_Name.value.length < 1) 
  {
    alert("Please provide a first name");
    document.sForm.First_Name.focus();
    value = false;
  }
  else if (document.sForm.Last_Name.value.length < 1) {
    alert("Please provide a last name");
    document.sForm.Last_Name.focus();
    value = false;
  }
  else if (document.sForm.Address.value.length < 1) {
    alert("Please provide your mailing address");
    document.sForm.Address.focus();
    value = false;
  }
  else if (document.sForm.Phone_Number.value.length < 10) {
    phone = document.sForm.Phone_Number.value;
    if (phone < 2000000000) 
    {
      alert("Please provide your phone number.");
      document.sForm.Phone_Number.focus();
      document.sForm.Phone_Number.select();
    }
    else {
      alert("Phone number requires area code with no dashes.");
      document.sForm.Phone_Number.focus();
      document.sForm.Phone_Number.select();
    }
    value = false;
  }
  else if (document.sForm.Email.value.length < 1 || document.sForm.Email.value.indexOf("@") <= 0)  
  {
    alert("Please provide a valid email address we can reach you at.");
    document.sForm.Email.focus();
    value = false;
  }
  else if (document.sForm.City.value.length < 1) {
    alert("Please provide your city.");
    document.sForm.City.focus();
    value = false;
  }
  else if (document.sForm.State.value.length < 1) {
    alert("Please provide your state.");
    document.sForm.State.focus();
    value = false;
  }
  else if (document.sForm.Zipcode.value.length < 1) {
    alert("Please provide your zipcode.");
    document.sForm.Zipcode.focus();
    value = false;
  }
  else if (document.sForm.Comments.value.length > 1024)
  {
    alert("Please Limit your comments to 1000 characters.");
    document.sForm.Zipcode.focus();
    value = false;
  }
  else 
  {
    value = true;
  }

  return value;

}
