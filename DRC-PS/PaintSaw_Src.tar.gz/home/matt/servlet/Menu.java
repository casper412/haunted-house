/* Dynamic Menu by Matthew Hall
 *
 */

import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Menu extends HttpServlet 
{
    private java.sql.Connection con	;
    private String url  		;
    private boolean m_init		;
    private Statement stmt		;
   
    //Applet Info
    private String applet_name = "basictoc3.class"	;
    private String archive     = "http://www.paintingwithasaw.com/basictoc3.jar" ;
    private String bgcolor     = "FBF8E8"		; 
    private String width       = "150"			;
    private String height      = "300"			;

    //On Init - Open SawPictures Database
    public void init() throws ServletException
    {
	url = "jdbc:mysql://localhost/SawPictures" ;
	m_init = true ;

	try 
	{
            Class.forName("com.mysql.jdbc.Driver");
	    con = DriverManager.getConnection (url, "matt", "asdf20g");
            stmt = con.createStatement();

        }
        catch(SQLException ex) 
	{
		m_init = false ;
        }
        catch(java.lang.ClassNotFoundException ex) 
	{
		m_init = false ;
	}

    }//end init
    
    //On Close - Close Connection
    public void destroy()
    {
	try
	{
        	stmt.close();
        	con.close() ;
	}
        catch(SQLException ex) 
	{
		//Do nothing we are exiting
	}

    }//end destroy
    
    //On Get - Query Database
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        ResourceBundle rb =
        ResourceBundle.getBundle("LocalStrings",request.getLocale());
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>");
        out.println("<head></head>");
	out.println("<body bgcolor=" + bgcolor + "><BR><BR>") ;
	out.println("<applet code=\"" + applet_name + "\" archive=\"" + archive + "\" " ) ;
	out.println("WIDTH=\"" + width + "\" HEIGHT=\"" + height + "\">") ;
	
	if(m_init)
	{	
	       //Load All Params
               String query = "SELECT * FROM menu";

               try 
	       {
		    //Print Params
            	    ResultSet result = stmt.executeQuery(query);
	            while (result.next()) 
		    {
                	String name = "<param name=\"" + result.getString(1) + 
					"\" value=\"" + result.getString(2) + "\" >";
	                out.println(name);
       		    }

 	       } 
       	       catch(SQLException ex) 
	       {
           	    out.println("SQLException: ");
            	    out.println(ex.getMessage());
               }
        
	       //Load TOCDATA Param	
	       query = "SELECT * FROM TOC";

               try 
	       {
		    String name = "<param name=\"TOCDATA\" value=\"" ;

            	    ResultSet result = stmt.executeQuery(query);
	            while (result.next()) 
		    {
                	name += result.getString(2) + ";" ;	
			name += result.getString(3) + ";" ;
			
			String temp = result.getString(4) ;
			if(temp.length() > 0)
			{
				name += temp + ";" ;
			}
			
			name += result.getString(5) + ";" ;
			name += result.getString(6) 	  ;

			name += "|\n\t" ;
       		    }
			
	            name += "\">" ;
                    out.println(name);

 	       } 
       	       catch(SQLException ex) 
	       {
           	    out.println("SQLException: ");
            	    out.println(ex.getMessage());
               }
	}
	else
	{
		out.println("Database Failed to Initialize...") ;
	}

	out.println("</applet>"); 
        out.println("</body>");
        out.println("</html>");
    }//end doGet

}//end class def



