<?php

/**
 * index.php -- Displays the main frameset
 *
 * Copyright (c) 1999-2003 The SquirrelMail Project Team
 * Licensed under the GNU GPL. For full terms see the file COPYING.
 *
 * Redirects to the login page.
 *
 * $Id: index.php,v 1.14.2.1 2003/07/27 19:38:44 kink Exp $
 */

header('Location: src/login.php');

?>
<html></html>
